# Publish to GitHub

**Not published by this session.** The connected profile resolved to `jojoxi0`. The lookup for `jojoxi0/soc-home-lab` returned 404, and the accessible repository list for this owner was empty. This means absent or inaccessible, not proof that no private repository exists. Available connector actions did not include repository creation. No unrelated content was changed.

## One-time account action

1. Sign in to your own GitHub account and inspect your repositories for `soc-home-lab`.
2. If it already exists, grant this integration access and inspect its work before merging this package. Do not overwrite useful files.
3. Otherwise open [New repository](https://github.com/new), choose your own account, name `soc-home-lab`, visibility Public. A suitable description is: “SOC learning lab: Windows telemetry, Wazuh detection examples and evidence-driven investigation runbooks. Deployment in progress.”
4. For connector continuation, initialize with a README and grant the GitHub integration access to this repository. Then send its URL back so the package can be committed after inspecting that README.

## Manual upload alternative

Extract the ZIP. Open its `soc-home-lab` folder: README.md must be at the repository root, not inside a second nested folder. Use GitHub's Add file → Upload files, upload the folder contents (include `.gitignore`), and use commit message `docs: add SOC lab design and honest validation runbooks`. If files already exist, inspect differences before committing.

Alternatively, with Git installed, clone the actual repository, copy the reviewed package contents into it preserving existing useful work, inspect `git diff` and `git status`, then stage only intended files and commit. Use your own configured Git identity. Do not put access tokens in commands or public files.

## Verify publication

Check README renders, the Mermaid diagram displays, all relative links open, XML files retain formatting, and no raw evidence or secrets were uploaded. Confirm public visibility in a signed-out window. Only then copy the actual repository URL into LinkedIn. No public URL is claimed to exist in this package.
